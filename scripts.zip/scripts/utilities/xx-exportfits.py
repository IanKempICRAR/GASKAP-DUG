exportfits(fitsimage='38466_askap_smooth.fits',imagename='38466_askap_smooth.image')
