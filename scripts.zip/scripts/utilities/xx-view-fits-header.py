
from astropy.io import fits

with fits.open('images/test/example-image.fits') and hdulist
   hdulist.info()
   for hdu in hdulist:
      print(repr(hdu.header))

