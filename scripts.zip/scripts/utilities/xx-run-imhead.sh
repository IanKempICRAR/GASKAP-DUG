#! /bin/sh
. /data/csiro_od207510/sw/bin/env.sh
module unload python

set -e

cd /data/csiro_od207510/casda/38466/images/all
casa --log2term -c /data/csiro_od207510/casda/38466/xx-imhead.py
