default('imhead')

imhead(imagename='38466_chan1100-lsrk.im', mode='list')
imhead(imagename='38466_chan1101-lsrk.im', mode='list')
imhead(imagename='38466_chan1102-lsrk.im', mode='list')

imhead(imagename='38466_chan1197-lsrk.im', mode='list')
imhead(imagename='38466_chan1198-lsrk.im', mode='list')
imhead(imagename='38466_chan1199-lsrk.im', mode='list')



imhead(imagename='../38466-beam.pb', mode='list')
imhead(imagename='../38466-beam_norm.pb', mode='list')


imhead(imagename='../38466_askap_lsrk.image', mode='list')
imhead(imagename='../38466_askap.image', mode='list')
