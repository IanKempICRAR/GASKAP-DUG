importfits(fitsimage='38466_gass.fits',imagename='38466_gass.image')
imsubimage(imagename='38466_gass.image',outfile='38466_gass_cube.image',dropdeg=True)
imsubimage(imagename='38466_askap_lsrk.image',outfile='38466_askap.image',dropdeg=True)
