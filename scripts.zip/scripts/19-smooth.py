imsmooth(imagename='38466_askap.image',outfile='38466_askap_smooth.image',kernel='commonbeam')
