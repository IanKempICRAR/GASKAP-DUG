import glob 

importfits(fitsimage='38466-beam.fits', imagename='38466-beam.pb')
