## imports
import argparse
import glob 

parser = argparse.ArgumentParser()
parser.add_argument('-f', '--fileExt', help = '<required> file extension (e.g., image)', required = True)
parser.add_argument('-d', '--freqRes', help = '<required> frequency resolution in kHz', required = True)
parser.add_argument('-o', '--outFile', help = '<required> name of FITS cube', required = True)
parser.add_argument('-r', '--restFreq', help = 'rest frequency in MHz (default is 1420.405752)', default = '1420.405752')
parser.add_argument('-l', '--refFrame', help = 'frqeuency reference frame (default is TOPO', default = 'TOPO')
args, unknown = parser.parse_known_args()

## unpack user arguments
fileExt = args.fileExt
restFreqStr = '%sMHz' % args.restFreq
freqResStr = '%skHz' % args.freqRes
outFile = args.outFile
refFrame = args.refFrame

## create list of files
fileList = glob.glob('*%s' % fileExt)

## ensure list is in ascending channel order
fileList.sort()

## combine images
ia.imageconcat(outfile = '%s.image' % outFile , axis=-1, infiles = fileList, relax = False)

## convert to LSRK
default('imreframe')

imreframe(imagename='%s.image' % outFile, output='%s_lsrk.image' % outFile, outframe='lsrk')

## write out FITS file
#default('exportfits')
#exportfits(imagename='%s_lsrk.combImage' % outFile, fitsimage='%s_lsrk.fits' % outFile, velocity=True, dropdeg=True)
