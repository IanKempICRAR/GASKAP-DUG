feather(imagename='SB38466_askap_parkes_PBC_JyB.comb',highres='38466_askap_smooth.image',lowres='38466_gass_corrected.image')
exportfits(fitsimage='SB38466_askap_parkes_PBC_JyB.fits',imagename='SB38466_askap_parkes_PBC_JyB.comb')
