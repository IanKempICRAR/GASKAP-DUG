import sys
import os

for i in range(2112):
    channel='{:04}'.format(i)
    print('\nchannel: ', channel)
#    os.system('mv '+channel+'/*-image.fits all/') 
    os.system('mv '+channel+'/*-image-pb.fits all/') 
#
#finish
