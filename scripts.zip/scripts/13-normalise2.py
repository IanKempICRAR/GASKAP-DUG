# ia.open('38509-beam.pb')
# clrec=ia.maxfit()
# immath(imagename=['38509_cube_pb_lsrk.combImage'],outfile='38509_cube_pb_lsrk_norm.combImage',expr="IM0/max")
immath(imagename=['38466-beam.pb'],outfile='38466-beam_norm.pb',expr="IM0/1.19633")
