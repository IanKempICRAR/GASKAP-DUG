#!/bin/bash

. /data/csiro_od207510/sw/bin/env.sh
# default python interferes with casa
module unload python
set -e
cd /data/csiro_od207510/casda/38466
casa --logfile "03-listobs.log" -c 03-listobs.py
