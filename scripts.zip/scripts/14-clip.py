import glob

filelist=glob.glob('all/*.im')

for file in filelist:
   immath(imagename=[file,'38466-beam_norm.pb'],outfile=file.replace('image.im','lsrk.im'),expr='iif(IM1>0.25,IM0,0.0)',imagemd=file)
