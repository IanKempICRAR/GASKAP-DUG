import glob 
#
fileList = glob.glob('*-image-pb.fits')

for file in fileList:
    importfits(fitsimage=file, imagename=file.replace('-pb.fits','.im'))
