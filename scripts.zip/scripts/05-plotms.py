import time
plotms(vis='/Volumes/One Touch/38509/scienceData.M355-07A.SB38509.M355-07A.beam16_SL_binned.ms',xaxis='channel',yaxis='Amp',plotfile='plotms.out',antenna='2',avgtime='600')
time.sleep(3600)
