import argparse

## parse user inputs
parser = argparse.ArgumentParser()
parser.add_argument('-l', help = '<required> interleaf, A, B or C', required = True)
parser.add_argument('-b', help='<required> beam, 00 to 35', required = True)
args=vars(parser.parse_args())
#
leaf=args['l']
ibeam=int(args['b'])
beam='{:02}'.format(ibeam)
#
default('split')
#
for ichannel in range (2112):
    chan='{:04}'.format(ichannel)
    split(vis='scienceData.M349-02A.SB38466.M349-02'+leaf+'.beam'+beam+'_SL_binned.ms.contsub', outputvis='chan/'+leaf+beam+'_'+chan+'.ms',spw='0:'+chan,datacolumn='data')
#
#finished
