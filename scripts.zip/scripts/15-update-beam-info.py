import glob

default(imhead)

filelist=glob.glob('*lsrk.im')

for file in filelist:
   imhead(imagename=file, mode='put', hdkey='beammajor', hdvalue='30arcsec')
   imhead(imagename=file, mode='put', hdkey='beamminor', hdvalue='30arcsec')
   imhead(imagename=file, mode='put', hdkey='beampa', hdvalue='0deg')
   imhead(imagename=file, mode='put', hdkey='telescope', hdvalue='ASKAP')
