ia.open('38466-beam.pb')
clrec=ia.maxfit()
maxi=clrec["component0"]["flux"]["value"][0]
print("maxi: ", maxi)
# immath(imagename=['38509_cube_pb_lsrk.combImage'],outfile='38509_cube_pb_lsrk_norm.combImage',expr="IM0/maxi")
