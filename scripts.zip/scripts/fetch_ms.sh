#!/bin/bash
# intended for downloading measurement sets from CASDA and untarring the contents
# (without writing to disk first)

[ $# -ge 1 ] || { echo >&2 "usage: $0 URL [SIZE]"; exit 1; }

url=$1
size=$2

[[ $url =~ ^http* ]] || { echo >&2 "$0: error: first argument must be a URL (got '$url')"; exit 1; }
[[ ${size:-0} =~ ^[0-9]+$ ]] || { echo >&2 "$0: error: second argument must be number of bytes (got '$size')"; exit 1; }

scriptdir=$(dirname $(which "$0"))

name=$(echo $url |grep -o '[A-Za-z0-9_.-]*\.ms\.tar' |head -n1 |sed 's/^2[2F]//; s/\.tar$//')
if [ -z "$name" ]; then
	name=$(basename "$url" |sed 's/?.*//')
	echo >&2 "$0: couldn't identify ms name from url; writing checksum to $name.dl_checksum"
fi

/d/sw/python/3.7.3/bin/python -E "$scriptdir"/fetch_url.py ${size:+-s $size} "$url" |
pv -r -t -e -i 30 ${size:+-s $size} -N "$name" |
tee >(md5sum |awk '{print $1}' >"$name.dl_checksum") |
tar -xkv |
awk 'NR==1 {dir=$0}  END {if(dir!=""){print "MS contents extracted to", dir}}' >&2

((rc=PIPESTATUS[0] | PIPESTATUS[3]))
exit $rc
