#! /bin/sh
/data/curtin_ikphd/sw/casa-6.4.0-16/bin/casa -c /data/curtin_ikphd/gaskap/07-makemask.py
