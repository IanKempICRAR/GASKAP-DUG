######################################## Libraries ########################################
#
import sys
import os
import numpy as np
from astropy.io import fits
#
######################################## do ###############################
hdu=fits.open('beam.fits')
data=hdu[0].data
mask_image=np.zeros(data.shape)
inds=np.where(data>0.85)
mask_image[inds]=1.0
fits.writeto('mask.fits',mask_image,header=hdu[0].header)
